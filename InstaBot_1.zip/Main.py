from InstaBot import InstaBot
from vpn import *
from time import  sleep

def Main():

    #bot.AddPeopleFromSuggested(3)
    #bot.UnfollowRandom(3)
    #following = bot.GetFollowersList()
    #followers = bot.GetFollowingList()
    #not_following_back = bot.GetNotFollowingBackList()
    #bot.followList(bot.GetFansList())
    #bot.followList(["kheir_abeed21"])

    '''
    connection = VpnConnect.getInstance()
    class myMethod(vpnMethod):
        def __init__(self,max):
            vpnMethod.__init__(self)


        def method(self):
            bot = InstaBot()
            bot.login()
            bot.viewFriendsStories(10)
            self.stop()

    method = myMethod(2)
    connection.startAction(method)
    '''

    bot = InstaBot()
    bot.login()
    bot.commentLastestPost(10)
    input("press enter to contiue")

if __name__ == "__main__":
    Main()

from enum import  Enum

class Constants(Enum):
    OK = 1
    LoginError= 1000
    FollowSuggestedError=2000
    UnfollowUserError=3000